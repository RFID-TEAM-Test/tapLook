<html>

<head lang="en">
		<meta charset="utf-8">
		<title>Edit Employee Database</title>
		<link rel="stylesheet" type="text/css" href="style.css">
<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #A9A9A9;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>
		
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>

	<script type="text/javascript">
$(document).ready(function(){
    $('#employeeTable').DataTable({
     "dom": '<"top" f><"bottom" t><"clear">'


    });
});

</script>
</head>
<body>
<ul>
	<li><a class="active" href="admin.php">Project Home</a></li>
	<li><a class="active" href="updateinfo.php">Edit Employee Database</a></li>
    <li><a class="active" href="accessHistory.php">Access History</a></li>
    <li><a class="active" href="statisticalInfo.php">Statistical Info</a></li>
    </ul>
<header>
       <h1>Edit Employee Database</h1>
      </header>


<?php
	include 'databaseConn.php';
session_start();

if(isset($_POST['edit'])){

  header("location:updateinfo.php");

}



$sql = "SELECT * FROM rfidtest.EMPLOYEEINFO";


$data = mysqli_query($conn, $sql);

echo "<table border=1 id=employeeTable style=width:100%>
<thead>
<tr>
<th>Employee ID</th>
<th>Position</th>
<th>Firstname</th>
<th>Lastname</th>
<th>Address</th>
<th>Telephone</th>
</tr>
</thead>";


echo "<tbody>";
while($record = mysqli_fetch_assoc($data)){
	echo"<tr>";
	echo"<form action=updateinfo.php method=post>";
    echo "<td>".$record['employeeID']."</td>";
    echo "<td>".$record['Position']."</td>";
    echo "<td>".$record['firstname']."</td>";
    echo "<td>".$record['lastname']."</td>";
    echo "<td>".$record['address']."</td>";
    echo "<td>".$record['tele']."</td>";
  	echo "<input type=hidden name=hidden value=".$record['employeeID']."<br>";
    echo "</tr>";

}
echo "</tbody>";

echo "</table>";

echo "<br>"."<br>";
	
  //<input type=submit name=edit value=Edit information>
?>

</body>
</html>


