<!DOCTYPE html>
<html>
<body>

<h1>PHP TESTING</h1>

<?php


?>

</body>
</html>

