<?php
session_start();




?>


<!--!DOCTYPE html> -->
<html> 
	<head lang="en">
		<meta charset="utf-8">
		<title>Registration Page</title>
		<link rel="stylesheet" type="text/css" href="style.css">
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

	<script type="text/javascript">

		function getConnectionData()
		{
			//global tempId; 
			
			 $.ajax({
			 	url: "commandQuery.php",
				type: "POST",
				//dataType: "json",
				async: false,
				data: {
					"display": 1

				},
				success: function(databaseData){


					parsedJSON = $.parseJSON(databaseData);  // take the JSON string data to convert it to obj to access key->value 
					
						//$('#statusID').html($.type(databaseData);
						$('#ReaderStatusID').val(parsedJSON.ReaderStatus);
						$('#ErrorCodeID').val(parsedJSON.ErrorCode);
						$('#ErrorExplainID').val(parsedJSON.ErrorExplain);
						$('#CardNumID').val(parsedJSON.CardID);  // return the value attribute 
						$('#employeeId').val(parsedJSON.CardID);
                      
						//sendId(tempId);
					
				},
				error: function(XMLHttpRequest, textStatus, errorThrown){
					//$('#statusID').append("Status: " + textStatus); 
					alert("Status: " + textStatus);
					alert("Error: " + errorThrown);
				}
				
			}); 
			//$('#statusID').load("commandQuery.php");
			
		}
		/*function sendId(id)
		{
			document.getElementById('fnameId').value = tempId;
			$.ajax({
			 	url: "process.php",
				type: "POST",
				//dataType: "json",
				async: false,
				data: {cardID:125}, 
				success: function(resp){
					content.html(resp);

				},
				error: function(XMLHttpRequest, textStatus, errorThrown){
					alert("Status: " + textStatus);
					alert("Error: " + errorThrown);
				}
			}); 

			//$.post('process.php',{cardID:125},function(){});
		}*/

		$(document).ready(function(){
			setInterval(function(){getConnectionData();},100);  // 2000 /100

		});


	</script>
	<!--<script type="text/javascript" src="bmi.js"></script> -->
	<!-- style="background-image: url(rfid3.jpg);" -->
	</head> 
	<ul>
	<li><a class="active" href="admin.php">Project Home</a></li>
	<li><a class="active" href="register.php">Register Employee</a></li>
	<li><a class="active" href="accessControl.php">Real-Time Access</a></li>
    <li><a class="active" href="accessHistory.php">Access History</a></li>
    <li><a class="active" href="statisticalInfo.php">Statistical Info</a></li>
    </ul>
	
	<body> 
	<header>
       <h1>Registration form </h1>
      </header>
			<nav class="nav">
			<table style="width:100%">
     			 <tr>
				<th>
				<img src="unknown.jpg" width="256" height="256" alt="Log file goes here" ;>
				</th>
				</tr>
				<tr>
				<td></td>
				</tr>
				</table>
				<button class="button">Take Photo</button> 
				<div id="statusID"> 


				</div>
		     	<h2>READER STATUS</h2>
				<input readonly type="text" name="id" id="ReaderStatusID" value="" placeholder="Not Connected">
				<br><br>
					<h2>ERROR CODE</h2>
					<input readonly type="text" name="id"  id="ErrorCodeID" value="" placeholder="RF_NULL">
					<br><br>
					<h2>ERROR EXPLANATION</h2>
					<input readonly type="text" name="id"  id="ErrorExplainID" value="" placeholder="RF_NULL">
					<br><br>
					<h2>Card ID</h2>
					<input readonly type="text" name="id"  id="CardNumID" value="" placeholder="RF_NULL">
			   
					
			</nav>
			<article>
	
	<div id="registerformId" class="registerformC" style="min-width:250px;">
			<form method="POST" action="process.php" class="registerC" id="registerId">
				
				<input type="hidden"  name="employeeNum" id="employeeId" required><br><br>
				<label for="fname" class="fname">First Name:</label><input type="text" name="fname" id="fnameId" required><br><br>
				<label for="lname" class="lname">Last Name:</label><input type="text" name="lname" id="lnameId" required><br><br>
				<label for="jobtitle" class="jobtitle">Job Title:</label><input type="text" name="jobtitle" id="jobtitleId" required><br><br>
				<label for="address" class="address">Address:</label><input type="text" name="address" id="addressId" required><br><br>
				<label for="tel" class="tel">Telephone#: </label><input type="text"  name="tel" id="telId" required><br><br>
				<input type="submit" value="Register Employee" id="registerInfoId">
			</form>
				
		</div>
		</article>

	</body>
</html>