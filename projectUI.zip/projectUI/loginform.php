<?php
	session_start();
	if(isset($_POST["loginName"]) && isset($_POST["password"]))
	{
		$_SESSION["loginName"] = $_POST["loginName"];
		$_SESSION["password"] = $_POST["password"];
		if( $_SESSION["loginName"] ==("Admin") && $_SESSION["password"] == ("password")){
		header("Location: admin.php");}
		else{
		header("Location: loginform.php");
		}
		exit;
	}
?>


<!--!DOCTYPE html> -->
<html> 
	<head lang="en">
		<meta charset="utf-8">
		<title>RFID SYSTEM</title>
		<link rel="stylesheet" type="text/css" href="style.css"> 
	<!--<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script> -->
	<!--<script type="text/javascript" src="bmi.js"></script> -->
	</head> 
	
	<body> 
	<ul>
	<li><a class="active" href="loginform.php">RFID PROJECT</a></li>
    </ul>
		
		<div id="formId">
			<form name="loginForm" method="POST" id="loginFormID">
				<h2 align="center">Login</h2> 
			
				
				
				
					
					
					<h2 align="center">Username: <input type="text" name="loginName" id="loginID align="center"></p>
					<h2 align="center">Password: <input type="password" name="password" id="passwordID align="center"></p>
				
				
					<input type="submit" value="Login" id="submitId">
					
			</form>
		</div>
				
		
	 
		
	</body> 
	

</html> 