<?php
	session_start(); 
	if(!isset($_SESSION["loginName"]) && !isset($_SESSION["password"]))
	{
		header("location:loginform.php");
	}
	if(isset($_POST["registerInfo"]))
	{
	
		$_SESSION["registerInfo"] = $_POST["registerInfo"];
		header("location:register.php");
		exit;
	}
	
	else if (isset($_POST["accessInfo"]))
		header("location:accessControl.php");
	
	else if (isset($_POST["statsData"])) 
		header("location:statisticalInfo.php");
	
	else if(isset($_POST["historyInfo"]))
		header("location:accessHistory.php");
		
	
	
		
?>

<!--!DOCTYPE html> -->
<html>
	<head  lang="en">
		<meta charset="utf-8">
		<title>RFID Menu Page</title> 
		<link rel="stylesheet" type="text/css" href="style.css">
		<!--<script type="text/javascript" src="change.js"></script> -->
		<style>
			body {
    				background-image: url("RFID-Tag.jpg");
    				background-repeat: no-repeat;
   					background-size: 100%;
   					background-attachment: fixed;
				}
		</style>
	</head> 
	<ul>
	<li><a class="active" href="loginform.php">LOG OUT</a></li>
    </ul>
	<body>
	
		<header>
			<h1 align=center> RFID PROJECT HOME PAGE </h1>
		</header>
	
		<form name="menuForm" method="POST" id="formMenuID">
		<table id="t1" align="center">
		
		<tr>
		<th></th>
		<th></th>
		</tr>
		
		<tr>
		    <td><input type="submit" value="Register Employee Information" name="registerInfo" id="registerID"> </th><br><br>
		    <td><input type="submit" value="View Real-Time Access Control" name="accessInfo" id="realtimeId"></td><br><br>
		</tr>
		<tr>
		<td><input type="submit" value="View Statistical information" name="statsData" id="statisticsId"> </td><br><br>
		<td><input type="submit" value="View Log information" name="historyInfo" id="logId"> </td><br><br>
		</tr>
		
		</table>
		</form>
		
	
	</body>
</html>
