<?php
$host="localhost";
$user="root";
$password="Douglas123#";
 $databasename = '”webcam”';
  $con = mysqli_connect($host, $user, $password, $databasename);

 ?>

