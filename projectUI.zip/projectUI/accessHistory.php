<?php
session_start();


?>

<!DOCTYPE html>
<html>
<head>
<title> Access History </title>
	<link rel="stylesheet" href="style.css">
	<!--<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script> -->
		<!--<script type="text/javascript" src="bmi.js"></script> -->
		<!-- style="background-image: url(rfid3.jpg);" -->
</head>

<body>
<ul>
	<li><a class="active" href="admin.php">Project Home</a></li>
	<li><a class="active" href="register.php">Register Employee</a></li>
	<li><a class="active" href="accessControl.php">Real-Time Access</a></li>
    <li><a class="active" href="accessHistory.php">Access History</a></li>
    <li><a class="active" href="statisticalInfo.php">Statistical Info</a></li>
    </ul>
<div class="container">
<header>
<h1>Access History log </h1>
</header>

</div>
<nav class="nav">
	
	
	 <a href="http://www.carleton.ca/" target="gframe"><h2>Click to access history </h2></a>
	 <br><br>


</nav>

<article>
<iframe src="http://www.google.com" height="700" width="100%" alt="Click link on the left to begin" name="gframe"></iframe>

</article>


</body>
</html>
