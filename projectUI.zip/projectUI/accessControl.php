<?php
session_start();

if(isset($_POST['editDB']))
  {
    header("updateinfo.php");
  }
  
?>

<!DOCTYPE html>
<html>
<head>
<title> Real time employee access </title>
	<link rel="stylesheet" href="style.css">
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

  <script type="text/javascript">

  function  getEmployeeInfo(id)
  {

       $.ajax({
        url: "commandQuery.php",
        type: "POST",
        async: false,
        data: {
          "displayInfo": 1,
          

        },
        success: function(databaseData){

          parsedJSON = $.parseJSON(databaseData);  // take the JSON string data to convert it to obj to access key->value 
          
            $('#eID').val(parsedJSON.EmployeeID);
            $('#fname').val(parsedJSON.FirstName);
            $('#lname').val(parsedJSON.LastName);
            $('#title').val(parsedJSON.JobTitle);
            $('#addrs').val(parsedJSON.Address);
            $('#tele').val(parsedJSON.TelephoneNumber);


        },
        error: function(XMLHttpRequest, textStatus, errorThrown){
          //$('#statusID').append("Status: " + textStatus); 
          alert("Status: " + textStatus);
          alert("Error: " + errorThrown);
        }
        
      }); 
      //$('#statusID').load

  }

    function getConnectionData()
    {
      
       $.ajax({
        url: "commandQuery.php",
        type: "POST",
        async: false,
        data: {
          "display": 1

        },
        success: function(databaseData){

          parsedJSON = $.parseJSON(databaseData);  // take the JSON string data to convert it to obj to access key->value 
          
            $('#ReaderStatusID').val(parsedJSON.ReaderStatus);
            $('#ErrorCodeID').val(parsedJSON.ErrorCode);
            $('#ErrorExplainID').val(parsedJSON.ErrorExplain);
            $('#CardNumID').val(parsedJSON.CardID);

            getEmployeeInfo(CardID);
          
        },
        error: function(XMLHttpRequest, textStatus, errorThrown){
          //$('#statusID').append("Status: " + textStatus); 
          alert("Status: " + textStatus);
          alert("Error: " + errorThrown);
        }
        
      }); 
      //$('#statusID').load("commandQuery.php");
      
    }

    $(document).ready(function(){
      setInterval(function(){getConnectionData();},100); // 2000 
    });


  </script>
</head>


<body>
<ul>
	  <li><a class="active" href="admin.php">Project Home</a></li>
    <li><a class="active" href="register.php">Register Employee</a></li>
    <li><a class="active" href="accessControl.php">Real-Time Access</a></li>
    <li><a class="active" href="accessHistory.php">Access History</a></li>
    <li><a class="active" href="statisticalInfo.php">Statistical Info</a></li>
  </ul>
	<div class="container">
	<header>
       <h1>Real-Time Employee Access </h1>
      </header>
	</div>

     <nav class="nav">
	
	
       <h2 style="color:red; text-align:center">STATUS: CLOCKED OUT</h2>
      <table style="width:100%">
      <tr>
      <th>
      <img src="unknown.jpg" width="256" height="256" alt="Log file goes here" ;>
	  </th>
	  </tr>
	  </table>
     <!-- <a href="http://www.carleton.ca" target="gframe"><p>Click to view recent access log info </p></a> -->
	  <br><br>

	  <h2>READER STATUS</h2><input readonly type="text" name="id" id="ReaderStatusID" value="" text-align: center><br>
		<h2>ERROR CODE</h2><input readonly type="text" name="id"  id="ErrorCodeID" value="" text-align: center><br>
		<h2>ERROR EXPLANATION<input readonly type="text" name="id"  id ="ErrorExplainID" value="" text-align: center> </h2>
    <h2>Card ID</h2><input readonly type="text" name="id"  id="CardNumID" value="" placeholder="RF_NULL">
	

      </nav>

<article>
 <form action="updateinfo.php" method="POST">
  <h2>Employee ID:
  <input readonly type="number" name="id" id="eID" value="" placeholder="Not Connected">
  <br><br>
  Last name:
  <input readonly type="text" name="id" id="lname" value="" placeholder="Not Connected">
  <br><br>
  First name:
  <input readonly type="text" name="id" id="fname" value="" placeholder="Not Connected">
  <br><br>
  Job Title:
  <input readonly type="text" name="id" id="title" value="" placeholder="Not Connected">
  <br><br>
  Telephone Number:
  <input readonly type="text" name="id" id="tele" value="" placeholder="Not Connected">
  <br><br>
  <input type="submit" name="editDB" value="Edit employee info" >  <!--  might delete this -->
  </h2>
</form> 
</article>


<article>
<iframe src="demo_iframe.htm" height="300" width="100%" alt="Click link on the left to begin" name="gframe"></iframe>

</article>




</body>
</html>
