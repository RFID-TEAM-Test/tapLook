<html>
<head lang="en">
		<meta charset="utf-8">
		<title>Edit Employee Database</title>
		<link rel="stylesheet" type="text/css" href="style.css">
<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>
		
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>

	<script type="text/javascript">
$(document).ready(function(){
    $('#employeeTable').DataTable({
     "dom": '<"top" f><"bottom" t><"clear">'


    });
});

</script>
</head>
<body>
<ul>
	<li><a class="active" href="admin.php">Project Home</a></li>
	<li><a class="active" href="displayDB.php">Edit Employee Database</a></li>
    <li><a class="active" href="accessHistory.php">Access History</a></li>
    <li><a class="active" href="statisticalInfo.php">Statistical Info</a></li>
    </ul>
<header>
       <h1>Edit Employee Database</h1>
      </header>


<?php

session_start();



	include 'databaseConn.php';

if(isset($_POST['update'])){

	$queryupdate = "UPDATE rfidtest.EMPLOYEEINFO SET employeeID='$_POST[eid]', Position='$_POST[position]', firstname='$_POST[firstname]', lastname='$_POST[lastname]', address='$_POST[address]', tele='$_POST[telephone]' WHERE employeeID = '$_POST[hidden]'";

	mysqli_query($conn, $queryupdate);
}

if(isset($_POST['delete'])){

	$deleteqry = "DELETE FROM rfidtest.EMPLOYEEINFO WHERE employeeID = '$_POST[hidden]'";

	mysqli_query($conn, $deleteqry);
}


$sql = "SELECT * FROM rfidtest.EMPLOYEEINFO";


$data = mysqli_query($conn, $sql);

echo "<table border=1 id=employeeTable style=width:100%>
<thead>
<tr>
<th>Employee ID</th>
<th>Position</th>
<th>Firstname</th>
<th>Lastname</th>
<th>Address</th>
<th>Telephone</th>
</tr>
</thead>";


echo "<tbody>";
while($record = mysqli_fetch_assoc($data)){
	echo"<tr>";

	echo"<form action=updateinfo.php method=post>";
	echo "<tbody>";
	echo "<tr>";
	echo "<td>" .$record['employeeID']."</td>";
	echo "<td>"."<input type=text name=position value=" . $record['Position']."></td>";
	echo "<td>"."<input type=text name=firstname value=" . $record['firstname']."></td>";
	echo "<td>"."<input type=text name=lastname value=" . $record['lastname']."></td>";
	echo "<td>"."<input type=text name=address value=" . $record['address']."></td>";
	echo "<td>"."<input type=text name=telephone value=" . $record['tele']."></td>";
	echo "<td>"."<input type=submit name=update value=Update>"."</td>";
	echo "<td>"."<input type=submit name=delete value=Delete>"."</td>";

	echo "</tr>";



	echo "</form>";
}
echo "</tbody>";

echo "</table>";


?>

</body>
</html>


