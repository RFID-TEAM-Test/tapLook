<?php
session_start();

?>

<!--!DOCTYPE html> -->
<html> 
	<head lang="en">
		<meta charset="utf-8">
		<title>Statistical Data Page</title>
	<!--<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script> -->
	<!--<script type="text/javascript" src="bmi.js"></script> -->
		<link rel="stylesheet" href="style.css">
	</head> 
	<style>

body {
    background-image: url("pie.jpg");
    background-repeat: no-repeat;
   background-size: 100%;
   
    background-attachment: fixed;
}
</style>
<ul>
	<li><a class="active" href="admin.php">Project Home</a></li>
	<li><a class="active" href="accessControl.php">View Real-Time Access</a></li>
    <li><a class="active" href="accessHistory.php">Access History</a></li>
    <li><a class="active" href="statisticalInfo.php">Statistical Info</a></li>
    </ul>

	<h2>Statistical Data Page</h2>
	<!-- <img src="6145.png" alt="Coming Soon" style="width:304px;height:228px;"> -->

	</body>
</html>